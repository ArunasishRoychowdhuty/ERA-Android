package com.eraassistant.mobile.device

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.accessibility.AccessibilityManager
import android.provider.ContactsContract
import com.eraassistant.mobile.accessibility.EraAccessibilityService
import com.eraassistant.mobile.planner.TaskCapability

/** Reports capabilities that are actually available on this device at runtime. */
class AndroidCapabilityDiscovery(private val context: Context) {
    fun discover(): Set<TaskCapability> = buildSet {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        if (pm.queryIntentActivities(launcher, 0).isNotEmpty()) add(TaskCapability.APP_LAUNCH)

        val consented = context.getSharedPreferences("era_preferences", Context.MODE_PRIVATE)
            .getBoolean("accessibility_consent_accepted", false)
        if (consented && isEraAccessibilityServiceEnabled()) {
            add(TaskCapability.SCREEN_OBSERVATION)
            add(TaskCapability.STRUCTURED_UI_ACTION)
            add(TaskCapability.TEXT_ENTRY)
        }

        val picker = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
        if (picker.resolveActivity(pm) != null) add(TaskCapability.CONTACT_PICKER)

        val mediaPicker = Intent(Intent.ACTION_GET_CONTENT).setType("image/*")
        if (mediaPicker.resolveActivity(pm) != null) add(TaskCapability.MEDIA_PICKER)

        val whatsapp = listOf("com.whatsapp", "com.whatsapp.w4b").any { packageName ->
            runCatching { pm.getPackageInfo(packageName, 0) }.isSuccess
        }
        if (whatsapp) add(TaskCapability.SHARE_DRAFT)

        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://example.invalid"))
        if (web.resolveActivity(pm) != null) add(TaskCapability.WEB_NAVIGATION)

        // These are available only when the user can review and approve actions in the app.
        add(TaskCapability.USER_CONFIRMATION)
    }

    fun isEraAccessibilityServiceEnabled(): Boolean {
        val manager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager ?: return false
        if (!manager.isEnabled) return false
        val expected = ComponentName(context, EraAccessibilityService::class.java)
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { info -> info.resolveInfo.serviceInfo.let { ComponentName(it.packageName, it.name) == expected } }
    }
}
